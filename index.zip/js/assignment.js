const addproductname = (name) => {
    let productList = document.getElementById("productol");
    let list = document.createElement("li");
    list.innerHTML = `${name}`;
    productList.appendChild(list);

}
document.getElementById('enable-done').addEventListener('keyup',function(event){
    const text = event.target.value;
    console.log(text)
    
    if(text === 'SELL200'){
        const text = text-(text/100)*20
        document.getElementById('tPrice').innerText = text
    }
    else{
      
    }

})
document.getElementById('btn-enable').addEventListener('click',function(){

})

const btnEnable = (val) => {
    if(val > 0){
        document.getElementById("makepur").removeAttribute("disable");
        document.getElementById("makepur").style.backgroundColor = "pink";
        document.getElementById("makepur").style.cursor = "pointer";
    }

    if(val > 200){
        document.getElementById("btn-enable").removeAttribute("disable");
        document.getElementById("btn-enable").style.background = "pink";
        document.getElementById("makepur").style.cursor = "pointer";
    }
}

document.getElementById('prod1-click').addEventListener('click', () => {
    addproductname("K. Accessories");
    let total = document.getElementById('tprice').innerText;
    let tprice = (39 + +total).toFixed(2);
    console.log(tprice)
    btnEnable(tprice)
    document.getElementById('tprice').innerHTML = tprice;
})
document.getElementById('prod2-click').addEventListener('click', () => {
    addproductname("K. Accessories");
    let total = document.getElementById('tprice').innerText;
    let tprice = (25 + +total).toFixed(2);
    console.log(tprice)
    btnEnable(tprice)
    document.getElementById('tprice').innerHTML = tprice;
})
document.getElementById('prod3-click').addEventListener('click', () => {
    addproductname("Home cooker");
    let total = document.getElementById('tprice').innerText;
    let tprice = (39 + +total).toFixed(2);
    console.log(tprice)
    btnEnable(tprice)
    document.getElementById('tprice').innerHTML = tprice;
})
document.getElementById('prod4-click').addEventListener('click', () => {
    addproductname("Sports back cap");
    let total = document.getElementById('tprice').innerText;
    let tprice = (49 + +total).toFixed(2);
    console.log(tprice)
    btnEnable(tprice)
    document.getElementById('tprice').innerHTML = tprice;
})
document.getElementById('prod5-click').addEventListener('click', () => {
    addproductname("Full Jersey Set");
    let total = document.getElementById('tprice').innerText;
    let tprice = (69 + +total).toFixed(2);
    console.log(tprice)
    btnEnable(tprice)
    document.getElementById('tprice').innerHTML = tprice;
})
document.getElementById('prod6-click').addEventListener('click', () => {
    addproductname("Sports cates");
    let total = document.getElementById('tprice').innerText;
    let tprice = (159 + +total).toFixed(2);
    console.log(tprice)
    btnEnable(tprice)
    document.getElementById('tprice').innerHTML = tprice;
})
