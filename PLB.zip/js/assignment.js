document.getElementById('enable-done').addEventListener('click',function(){
    const text = document.getElementById('btn-enable');
    const button = text.value;
    console.log(text);
})